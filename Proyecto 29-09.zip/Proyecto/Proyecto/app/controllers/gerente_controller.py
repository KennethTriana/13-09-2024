from flask import Blueprint, render_template, request, redirect, url_for, current_app
from flask_bcrypt import Bcrypt
from flask import session
import os
from werkzeug.utils import secure_filename


gerente_bp = Blueprint('gerente_bp', __name__)
bcrypt = Bcrypt()

@gerente_bp.route('/ingresar', methods=['GET', 'POST'])
def Entrada():
    connection = current_app.connection
    if request.method == 'POST':
        producto = request.form['producto']
        presentacion = request.form['presentacion']
        codigo = request.form['codigo']
        categoria = request.form['categoria']
        Fechaentrada = request.form['Fechaentrada']
        Fechasalida = request.form['Fechasalida']
        cantidad = request.form['cantidad']
        Valorentrada = request.form['Valorentrada']
        Valorsalida = request.form['Valorsalida']
        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO Productos (producto, presentacion, codigo, categoria) VALUES (%s, %s, %s, %s)",
                    (producto, presentacion, codigo, categoria)
                )
                cursor.execute(
                "INSERT INTO DetalleProductos (codigo, Fechaentrada, Fechasalida, cantidad, Valorentrada, Valorsalida) VALUES (%s, %s, %s, %s, %s, %s)",
                    (codigo, Fechaentrada, Fechasalida, cantidad, Valorentrada, Valorsalida)
                )
                cursor.execute(
                    "INSERT INTO ProductosIngresados (producto, presentacion, codigo, categoria) VALUES (%s, %s, %s, %s)",
                    (producto, presentacion, codigo, categoria)
                )
                cursor.execute(
                "INSERT INTO DetalleProductosIngresados (codigo, Fechaentrada, Fechasalida, cantidad, Valorentrada, Valorsalida) VALUES (%s, %s, %s, %s, %s, %s)",
                    (codigo, Fechaentrada, Fechasalida, cantidad, Valorentrada, Valorsalida)
                )
                connection.commit()
            return redirect(url_for('gerente_bp.Gerente_1.html'))
        
        except Exception as e:
            return str(e)
    try:
         with connection.cursor() as cursor:
              cursor.execute("SELECT * FROM Productos")
    except Exception as e:
          return str(e)

    return render_template('Gerente_1.html')

@gerente_bp.route('/salida', methods=['GET', 'POST'])
def Salida():
    connection = current_app.connection
    if request.method == 'POST':
        producto = request.form['producto']
        presentacion = request.form['presentacion']
        codigo = request.form['codigo']
        categoria = request.form['categoria']
        Fechaentrada = request.form['Fechaentrada']
        Fechasalida = request.form['Fechasalida']
        cantidad = request.form['cantidad']
        Valorsalida = request.form['Valorsalida']

        try:
            with connection.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO Factura (producto, presentacion, codigo, categoria) VALUES (%s, %s, %s, %s)",
                    (producto, presentacion, codigo, categoria)
                )
                cursor.execute(
                    "INSERT INTO DetalleFactura (Fechaentrada, Fechasalida, cantidad, Valorsalida) VALUES (%s, %s, %s, %s)",
                    (Fechaentrada, Fechasalida, cantidad, Valorsalida)
                )
                cursor.execute(
                    "DELETE FROM Productos WHERE codigo = %s",
                    (codigo,)
                )
                cursor.execute(
                    "DELETE FROM DetalleProductos WHERE codigo = %s",
                    (codigo,)
                )
                connection.commit()

            return redirect(url_for('gerente_bp.Gerente_2')) 
        
        except Exception as e:
            return str(e)

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM Productos")
            productos = cursor.fetchall()

    except Exception as e:
        return str(e)

    return render_template('Gerente_2.html', productos=productos)

@gerente_bp.route('/productos', methods=['GET'])
def mostrar_inventario():
    connection = current_app.connection
    productos = []

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT codigo, producto, presentacion, categoria FROM productos")
            productos = cursor.fetchall()

            cursor.execute("SELECT cantidad, Fechaentrada, Fechasalida FROM Detalleproductos")
            productos = cursor.fetchall()

    except Exception as e:
        return str(e)

    return render_template('Inventario.html', productos=productos)

@gerente_bp.route('/productos', methods=['GET'])
def mostrar_entradas():
    connection = current_app.connection
    productos = []

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT codigo, producto, presentacion, categoria FROM Productosingresados")
            productos = cursor.fetchall()

            cursor.execute("SELECT cantidad, Fechaentrada, Fechasalida FROM DetalleProductosingresados")
            productos = cursor.fetchall()

    except Exception as e:
        return str(e)

    return render_template('Entradas.html', productos=productos)

@gerente_bp.route('/productos', methods=['GET'])
def mostrar_salidas():
    connection = current_app.connection
    productos = []

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT codigo, producto, presentacion, categoria FROM Factura")
            productos = cursor.fetchall()

            cursor.execute("SELECT cantidad, Fechaentrada, Fechasalida FROM DetalleFactura")
            productos = cursor.fetchall()

    except Exception as e:
        return str(e)

    return render_template('Salidas.html', productos=productos)

@gerente_bp.route('/entrada', methods=['POST'])
def registrar_entrada():
    producto_codigo = request.form['codigo']
    cantidad_entrada = int(request.form['cantidad'])

    connection = current_app.connection

    try:
        with connection.cursor() as cursor:
            cursor.execute("UPDATE productos SET cantidad = cantidad + %s WHERE id = %s", (cantidad_entrada, producto_codigo))

            cursor.execute("""
                INSERT INTO movimientos (producto_id, tipo, cantidad, fecha)
                VALUES (%s, 'entrada', %s, NOW())
            """, (producto_codigo, cantidad_entrada))

        connection.commit()
    except Exception as e:
        connection.rollback()
        return str(e)

    return "Entrada registrada exitosamente"

@gerente_bp.route('/salida', methods=['POST'])
def registrar_salida():
    producto_codigo = request.form['codigo']
    cantidad_salida = int(request.form['cantidad'])

    connection = current_app.connection

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT cantidad FROM productos WHERE id = %s", (producto_codigo,))
            stock_actual = cursor.fetchone()[0]

            if stock_actual < cantidad_salida:
                return "No hay suficiente stock para realizar esta salida"

            cursor.execute("UPDATE productos SET cantidad = cantidad - %s WHERE id = %s", (cantidad_salida, producto_codigo))

            cursor.execute("""
                INSERT INTO movimientos (producto_codigo, tipo, cantidad, fecha)
                VALUES (%s, 'salida', %s, NOW())
            """, (producto_codigo, cantidad_salida))

        connection.commit()
    except Exception as e:
        connection.rollback()
        return str(e)

    return "Salida registrada exitosamente"

@gerente_bp.route('/productos', methods=['GET'])
def mostrar_inventario():
    connection = current_app.connection
    productos = []

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT codigo, producto, presentacion, categoria FROM Productos")
            productos = cursor.fetchall()

            cursor.execute("SELECT cantidad, Fechaentrada, Fechasalida FROM DetalleProductos")
            productos = cursor.fetchall()

    except Exception as e:
        return str(e)

    return render_template('Inventario.html', productos=productos)

@gerente_bp.route('/alertas', methods=['GET'])
def alertas_bajo_stock():
    connection = current_app.connection
    productos_bajo_stock = []
    try:
        umbral_stock_bajo = 10
        with connection.cursor() as cursor:
            cursor.execute("SELECT codigo, producto, cantidad FROM productos WHERE cantidad < %s", (umbral_stock_bajo,))
            productos_bajo_stock = cursor.fetchall()

    except Exception as e:
        return str(e)

    return render_template('Alerta.html', productos=productos_bajo_stock)