class Config:
    SECRET_KEY = 'inventario'  # Cambia esto por una clave segura
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = ''  # Cambia por tu contraseña de MySQL
    MYSQL_DB = 'autoservicio'    # Nombre de tu base de datos
    SESSION_COOKIE_SECURE = False  # Ajusta según sea necesarios